package com.example.electroduo;

public class Usuario {
    private String id;         // ID del usuario
    private String password;   // Contraseña del usuario
    private String type;       // Tipo de usuario (ej. DOCTOR, PACIENTE)
    private String nombre;     // Nombre del usuario
    private String sintomas;   // Síntomas del paciente
    private String doctorId;   // ID del doctor
    private String messages;    // Mensajes del usuario

    // Constructor
    public Usuario(String id, String password, String type, String nombre, String sintomas, String doctorId, String messages) {
        this.id = id;
        this.password = password;
        this.type = type;
        this.nombre = nombre;
        this.sintomas = sintomas;
        this.doctorId = doctorId; // Asignar el ID del doctor
        this.messages = messages; // Asignar los mensajes
    }

    // Constructor simplificado para el Spinner
    public Usuario(String id, String nombre, String sintomas) {
        this.id = id;
        this.nombre = nombre;
        this.sintomas = sintomas; // Asignar síntomas
        this.type = "PACIENTE"; // Asignar tipo por defecto
        this.doctorId = ""; // Inicializar doctorId
        this.messages = ""; // Inicializar mensajes como vacío
    }

    public String toString() {
        return nombre + " (" + id + ")"; // Mostrar el nombre y el ID en el Spinner
    }

    // Getters y Setters
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getType() {
        return type;
    }
    public void setTipo(String tipo) {
        this.type = type;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getSintomas() {
        return sintomas;
    }
    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }
    public String getDoctorId() {
        return doctorId;
    }
    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }
    public String getMessages() {
        return messages; // Método getter para los mensajes
    }
    public void setMessages(String messages) {
        this.messages = messages; // Método setter para los mensajes
    }
}
