package com.example.electroduo;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "UserDatabase";
    public static final int DATABASE_VERSION = 8;

    // Tabla Usuarios
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_NOMBRE = "nombre";
    public static final String COLUMN_SINTOMAS = "sintomas";
    public static final String COLUMN_DOCTOR_ID = "doctor_id";
    public static final String COLUMN_MESSAGES = "messages";

    // SQL para crear la tabla de usuarios
    private static final String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_ID + " TEXT PRIMARY KEY, " +
            COLUMN_PASSWORD + " TEXT, " +
            COLUMN_TYPE + " TEXT, " +
            COLUMN_NOMBRE + " TEXT, " +
            COLUMN_SINTOMAS + " TEXT, " +
            COLUMN_DOCTOR_ID + " TEXT, " +
            COLUMN_MESSAGES + " TEXT)"; // Nueva columna para mensajes

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        addUser (db, "D01", "123", "DOCTOR", "JOSE LUIS", "Ninguno", "D01", ""); // Mensajes vacíos
        addUser (db, "D02", "123", "DOCTOR", "MIA JOHNSON", "Ninguno", "D02", ""); // Mensajes vacíos
        addUser (db, "D03", "123", "DOCTOR", "YAGUARU", "Ninguno", "D03", ""); // Mensajes vacíos
        addUser (db, "P01", "123", "PACIENTE", "PEDRO", "", "D01", ""); // Mensajes vacíos
        addUser (db, "P02", "123", "PACIENTE", "PABLO", "", "D01", ""); // Mensajes vacíos
        addUser (db, "P03", "123", "PACIENTE", "JUAN", "", "D02", ""); // Mensajes vacíos
        addUser (db, "P04", "123", "PACIENTE", "IGNACIO", "", "D02", ""); // Mensajes vacíos
        addUser (db, "P05", "123", "PACIENTE", "ANA", "", "D03", ""); // Mensajes vacíos
        addUser (db, "P06", "123", "PACIENTE", "LAURA", "", "D03", ""); // Mensajes vacíos
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Método para añadir un nuevo usuario
// Método para añadir un nuevo usuario
    private void addUser (SQLiteDatabase db, String id, String password, String type, String nombre, String sintomas, String doctorId, String messages) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, id);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_TYPE, type);
        values.put(COLUMN_NOMBRE, nombre);
        values.put(COLUMN_SINTOMAS, sintomas);
        values.put(COLUMN_DOCTOR_ID, doctorId); // Agregar el ID del doctor
        values.put(COLUMN_MESSAGES, messages); // Agregar mensajes
        db.insert(TABLE_USERS, null, values);
    }
// Método para verificar las credenciales del usuario
public Usuario checkUser (String id, String password) {
    SQLiteDatabase db = this.getReadableDatabase();
    Cursor cursor = null;
    try {
        cursor = db.query(TABLE_USERS, new String[]{COLUMN_ID, COLUMN_PASSWORD, COLUMN_TYPE, COLUMN_NOMBRE, COLUMN_SINTOMAS, COLUMN_DOCTOR_ID, COLUMN_MESSAGES},
                COLUMN_ID + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{id, password}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            Log.d("DatabaseCheck", "Usuario encontrado: " + cursor.getString(0));
            // Obtener los valores de sintomas y doctorId
            @SuppressLint("Range") String sintomas = cursor.getString(cursor.getColumnIndex(COLUMN_SINTOMAS));
            @SuppressLint("Range") String doctorId = cursor.getString(cursor.getColumnIndex(COLUMN_DOCTOR_ID));
            @SuppressLint("Range") String messages = cursor.getString(cursor.getColumnIndex(COLUMN_MESSAGES)); // Obtener los mensajes
            return new Usuario(cursor.getString(0), password, cursor.getString(2), cursor.getString(3), sintomas, doctorId, messages); // Llamada al constructor actualizado
        } else {
            Log.d("DatabaseCheck", "Usuario no encontrado o credenciales incorrectas");
        }
    } catch (Exception e) {
        Log.e("DatabaseError", "Error al verificar el usuario", e);
    } finally {
        if (cursor != null) {
            cursor.close();
        }
    }
    return null;
}

    public List<Usuario> getAllPatients(String doctorId) {
        List<Usuario> patientList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, "type=? AND doctor_id=?", new String[]{"PACIENTE", doctorId}, null, null, null); // Filtrar por tipo PACIENTE y doctor_id

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(COLUMN_ID));
                @SuppressLint("Range") String nombre = cursor.getString(cursor.getColumnIndex(COLUMN_NOMBRE));
                @SuppressLint("Range") String sintomas = cursor.getString(cursor.getColumnIndex(COLUMN_SINTOMAS)); // Obtener síntomas
                patientList.add(new Usuario(id, nombre, sintomas)); // Crear un nuevo objeto Usuario con síntomas
            }
            cursor.close();
        }
        return patientList;
    }
    @SuppressLint("Range")
    public String getSymptomsByPatientId(String patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        String sintomas = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_SINTOMAS},
                    COLUMN_ID + "=?", new String[]{patientId}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                sintomas = cursor.getString(cursor.getColumnIndex(COLUMN_SINTOMAS));
            }
        } catch (Exception e) {
            Log.e("DatabaseError", "Error al obtener síntomas", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return sintomas;
    }
    public void clearSymptomsByPatientId(String patientId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SINTOMAS, ""); // Establecer los síntomas a una cadena vacía
        // Actualizar los síntomas del paciente
        db.update(TABLE_USERS, values, COLUMN_ID + "=?", new String[]{patientId});

    }
    public void addMessage(String patientId, String message) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        // Obtener la fecha y hora actual
        String currentDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        // Concatenar la fecha y hora al mensaje
        String messageWithDate = currentDateTime + " - " + message;
        // Obtener el mensaje existente
        String existingMessages = getMessagesByPatientId(patientId);
        // Concatenar el nuevo mensaje
        if (existingMessages != null && !existingMessages.isEmpty()) {
            messageWithDate = existingMessages + "\n" + messageWithDate; // Añadir el nuevo mensaje
        }
        values.put(COLUMN_MESSAGES, messageWithDate);
        db.update(TABLE_USERS, values, COLUMN_ID + "=?", new String[]{patientId});
        db.close();
    }

    @SuppressLint("Range")
    public String getMessagesByPatientId(String patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        String messages = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_MESSAGES},
                    COLUMN_ID + "=?", new String[]{patientId}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                messages = cursor.getString(cursor.getColumnIndex(COLUMN_MESSAGES));
            }
        } catch (Exception e) {
            Log.e("DatabaseError", "Error al obtener mensajes", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return messages;
    }
}