package com.example.electroduo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class DOCTOR extends AppCompatActivity {
    private TextView textViewNombre;
    private Button buttonOut;
    private Spinner spinnerPacientes;
    private Button buttonVerSintomas;
    private TextView textViewSL; // Añadir el TextView para mostrar síntomas
    private DatabaseHelper dbHelper;
    private List<Usuario> pacientes; // Lista de usuarios (pacientes)
    //private Button buttonEliminarSintomas; // Nuevo botón para eliminar síntomas
    private String selectedPatientId;
    private EditText editTextMessage; // Agrega esto en tu clase DOCTOR
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_doctor);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        spinnerPacientes = findViewById(R.id.spinnerPacientes);
        buttonVerSintomas = findViewById(R.id.buttonVerSintomas);
        //buttonEliminarSintomas = findViewById(R.id.buttonEliminarSintomas); // Inicializa el botón para eliminar síntomas
        textViewNombre = findViewById(R.id.textViewNombre);
        textViewSL = findViewById(R.id.textViewSL); // Inicializa el TextView para síntomas
        dbHelper = new DatabaseHelper(this);
        textViewNombre = findViewById(R.id.textViewNombre);
        buttonOut = findViewById(R.id.buttonOut);
        editTextMessage = findViewById(R.id.editTextMessage);
        Button buttonEnviarMensaje = findViewById(R.id.buttonEnviarMensaje);

        // Mostrar el nombre del doctor
        String nombre = getIntent().getStringExtra("nombre");
        String doctorId = getIntent().getStringExtra("doctorId");
        // Cargar pacientes
        loadPatients(doctorId);// Asegúrate de que este ID se pase al iniciar la actividad
        if (nombre != null) {
            textViewNombre.setText(nombre); // Muestra el nombre del doctor
        }


        // Configurar el botón de salir
        buttonOut = findViewById(R.id.buttonOut);
        buttonOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DOCTOR.this, MainActivity.class);
                startActivity(intent);
                finish(); // Opcional: cierra la actividad actual
            }
        });

        // Configurar el botón de ver sintomas
        buttonVerSintomas.setOnClickListener(view -> {
            if (selectedPatientId != null) {
                // Obtener los síntomas del paciente seleccionado
                String sintomas = dbHelper.getSymptomsByPatientId(selectedPatientId);
                if (sintomas != null && !sintomas.isEmpty()) {
                    textViewSL.setText(sintomas); // Mostrar los síntomas en el TextView
                } else {
                    textViewSL.setText("No hay síntomas registrados para este paciente.");
                }
            } else {
                Toast.makeText(DOCTOR.this, "Por favor, selecciona un paciente.", Toast.LENGTH_SHORT).show();
            }
        });

        // Configurar el botón para eliminar síntomas

        /*
        buttonEliminarSintomas.setOnClickListener(view -> {
            if (selectedPatientId != null) {
                dbHelper.clearSymptomsByPatientId(selectedPatientId); // Llamar al método para eliminar síntomas
                textViewSL.setText("No hay síntomas registrados."); // Actualizar el TextView
                Toast.makeText(DOCTOR.this, "Síntomas eliminados.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(DOCTOR.this, "Por favor, selecciona un paciente.", Toast.LENGTH_SHORT).show();
            }
        });
        */


        // Configurar el botón para enviar mensaje
        buttonEnviarMensaje.setOnClickListener(view -> {
            String message = editTextMessage.getText().toString().trim();
            if (!message.isEmpty() && selectedPatientId != null) {
                // Llamar al método addMessage del DatabaseHelper
                dbHelper.addMessage(selectedPatientId, message);
                editTextMessage.setText(""); // Limpiar el campo de texto
                Toast.makeText(DOCTOR.this, "Mensaje enviado.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(DOCTOR.this, "Por favor, escribe un mensaje.", Toast.LENGTH_SHORT).show();

            }

        });
    }
    private void loadPatients(String doctorId) {
        pacientes = dbHelper.getAllPatients(doctorId); // Obtener pacientes relacionados con el doctor
        ArrayAdapter<Usuario> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, pacientes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPacientes.setAdapter(adapter);
        spinnerPacientes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedPatientId = pacientes.get(position).getId(); // Obtener el ID del paciente seleccionado
                textViewSL.setText("No hay síntomas registrados."); // Restablecer el mensaje de síntomas
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedPatientId = null;
                textViewSL.setText("No hay síntomas registrados."); // Restablecer el mensaje de síntomas
            }
        });
    }
}