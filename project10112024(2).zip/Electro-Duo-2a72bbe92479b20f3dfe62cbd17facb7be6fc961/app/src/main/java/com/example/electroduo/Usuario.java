package com.example.electroduo;

public class Usuario {
    private String id;         // ID del usuario
    private String password;   // Contraseña del usuario
    private String type;       // Tipo de usuario (ej. DOCTOR, PACIENTE)
    private String nombre;
    private String sintomas; // Nombre del usuario

    // Constructor
    public Usuario(String id, String password, String type, String nombre) {
        this.id = id;
        this.password = password;
        this.type = type;
        this.nombre = nombre;
        this.sintomas = sintomas;
    }

    public String toString() {
        return nombre + " (" + id + ")"; // Mostrar el nombre y el ID en el Spinner
    }

    public Usuario(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    // Getters y Setters
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getType() { // Método getTipo agregado
        return type;
    }
    public void setTipo(String tipo) { // Método setTipo agregado
        this.type = type;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getSintomas() { // Método getter para síntomas
        return sintomas;
    }
}
