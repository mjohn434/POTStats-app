package com.example.electroduo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PACIENTE extends AppCompatActivity {
    private Button buttonOut;
    private TextView textViewN;
    private Button buttonAgregarSintomas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_paciente);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        textViewN = findViewById(R.id.textViewN); // Asegúrate de tener este TextView en tu layout
        String nombre = getIntent().getStringExtra("nombre");
        if (nombre != null) {
            textViewN.setText(nombre); // Muestra el nombre del paciente
        }
        buttonAgregarSintomas = findViewById(R.id.buttonAgregarSintomas); // Inicializar el nuevo botón
        buttonAgregarSintomas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar a la actividad de agregar síntomas
                Intent intent = new Intent(PACIENTE.this, AgregarSintomasActivity.class);
                intent.putExtra("patient_id", getIntent().getStringExtra("id")); // Pasar el ID del paciente
                startActivity(intent);
            }
        });
        buttonOut = findViewById(R.id.buttonOut);
        buttonOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PACIENTE.this, MainActivity.class);
                startActivity(intent);
                finish(); // Opcional: cierra la actividad actual
            }
        });
    }
}
