package com.example.electroduo;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "UserDatabase";
    public static final int DATABASE_VERSION = 5;

    // Tabla Usuarios
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_NOMBRE = "nombre";
    public static final String COLUMN_SINTOMAS = "sintomas"; // Nueva columna// Asegúrate de que esto esté definido

    // SQL para crear la tabla de usuarios
    private static final String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_ID + " TEXT PRIMARY KEY, " +
            COLUMN_PASSWORD + " TEXT, " +
            COLUMN_TYPE + " TEXT, " +
            COLUMN_NOMBRE + " TEXT, " +
            COLUMN_SINTOMAS + " TEXT)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        addUser (db, "D01", "123", "DOCTOR", "JOSE LUIS", "Ninguno");
        addUser (db, "D02", "123", "DOCTOR", "MIA JOHNSON", "Ninguno");// Agregar nombre
        addUser (db, "P01", "123", "PACIENTE", "PEDRO", ""); // Agregar nombre
        addUser (db, "P02", "123", "PACIENTE", "PABLO", "");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Método para añadir un nuevo usuario
    private void addUser (SQLiteDatabase db, String id, String password, String type, String nombre, String sintomas) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, id);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_TYPE, type);
        values.put(COLUMN_NOMBRE, nombre); // Agregar el nombre
        values.put(COLUMN_SINTOMAS, sintomas); // Agregar síntomas
        db.insert(TABLE_USERS, null, values);
    }
// Método para verificar las credenciales del usuario
    public Usuario checkUser  (String id, String password) {
    SQLiteDatabase db = this.getReadableDatabase();
    Cursor cursor = null;
    try {
        cursor = db.query(TABLE_USERS, new String[]{COLUMN_ID, COLUMN_PASSWORD, COLUMN_TYPE, COLUMN_NOMBRE},
                COLUMN_ID + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{id, password}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            Log.d("DatabaseCheck", "Usuario encontrado: " + cursor.getString(0));
            return new Usuario(cursor.getString(0), password, cursor.getString(2), cursor.getString(3));
        } else {
            Log.d("DatabaseCheck", "Usuario no encontrado o credenciales incorrectas");
        }
    } catch (Exception e) {
        Log.e("DatabaseError", "Error al verificar el usuario", e);
    } finally {
        if (cursor != null) {
            cursor.close();
        }
    }
    return null;
    }

    public List<Usuario> getAllPatients() {
        List<Usuario> patientList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, "type=?", new String[]{"PACIENTE"}, null, null, null); // Filtrar por tipo PACIENTE

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(COLUMN_ID));
                @SuppressLint("Range") String nombre = cursor.getString(cursor.getColumnIndex(COLUMN_NOMBRE)); // Asegúrate de que COLUMN_NOMBRE exista
                patientList.add(new Usuario(id, nombre)); // Crea un nuevo objeto Usuario
            }
            cursor.close();
        }
        return patientList;
    }
    @SuppressLint("Range")
    public String getSymptomsByPatientId(String patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sintomas = "";
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_SINTOMAS},
                COLUMN_ID + "=?", new String[]{patientId}, null, null, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                sintomas = cursor.getString(cursor.getColumnIndex(COLUMN_SINTOMAS));
            }
            cursor.close();
        }
        return sintomas;
    }
}