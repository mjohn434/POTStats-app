package com.interpretingVJ;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class ECGGraphView extends View {
    private Paint paint;
    private List<Float> data = new ArrayList<>(); // Datos del ECG
    private float maxDataValue = 127f; // Ajusta según el rango de tus datos
    private float minDataValue = -128f;

    public ECGGraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ECGGraphView(Context context) {
        super(context);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setStrokeWidth(3f);
        paint.setStyle(Paint.Style.STROKE);
        paint.setAntiAlias(true);
    }

    public void setData(List<Float> data) {
        this.data = data;
        invalidate(); // Redibuja el gráfico
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (data == null || data.isEmpty()) return;

        float width = getWidth();
        float height = getHeight();

        // Escalar datos al tamaño de la vista
        float xScale = width / (float) data.size();
        float yScale = height / (maxDataValue - minDataValue);

        // Dibujar el gráfico
        float previousX = 0;
        float previousY = height - (data.get(0) - minDataValue) * yScale;

        for (int i = 1; i < data.size(); i++) {
            float currentX = i * xScale;
            float currentY = height - (data.get(i) - minDataValue) * yScale;

            canvas.drawLine(previousX, previousY, currentX, currentY, paint);

            previousX = currentX;
            previousY = currentY;
        }
    }
}

