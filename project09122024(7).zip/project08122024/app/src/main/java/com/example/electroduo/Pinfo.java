package com.example.electroduo;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Pinfo extends LinearLayout {
    private TextView textViewId, textViewNombre, textViewEdad, textViewTelefono, textViewNumeroHistorial;
    private TextView textViewGenero, textViewHeight, textViewWeight, textViewMedications, textViewDiagnoses;

    public Pinfo(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public Pinfo(Context context) {
        super(context);
        init(context);
    }

    private void init(Context context) {
        LayoutInflater.from(context).inflate(R.layout.activity_pinfo, this, true);

        textViewId = findViewById(R.id.textViewId);
        textViewNombre = findViewById(R.id.textViewNombre);
        textViewEdad = findViewById(R.id.textViewEdad);
        textViewTelefono = findViewById(R.id.textViewTelefono);
        textViewNumeroHistorial = findViewById(R.id.textViewNumeroHistorial);
        textViewGenero = findViewById(R.id.textViewGenero);
        textViewHeight = findViewById(R.id.textViewHeight);
        textViewWeight = findViewById(R.id.textViewWeight);
        textViewMedications = findViewById(R.id.textViewMedications);
        textViewDiagnoses = findViewById(R.id.textViewDiagnoses);
    }

    public void setPatientData(Usuario paciente) {
        if (paciente != null) {
            textViewId.setText("ID: " + paciente.getId());
            textViewNombre.setText("Name: " + paciente.getNombre());
            textViewEdad.setText("Age: " + paciente.getAge());
            textViewTelefono.setText("Telephone Number: " + paciente.getPhoneNumber());
            textViewNumeroHistorial.setText("Medical Record Number: " + paciente.getMedicalRecordNumber());
            textViewGenero.setText("Gender: " + paciente.getGender());
            textViewHeight.setText("Height: " + paciente.getHeight() + " m");
            textViewWeight.setText("Weight: " + paciente.getWeight() + " kg");
            textViewMedications.setText("Medications: " + paciente.getMedications());
            textViewDiagnoses.setText("Diagnostics: " + paciente.getDiagnoses());
        }
    }
}
