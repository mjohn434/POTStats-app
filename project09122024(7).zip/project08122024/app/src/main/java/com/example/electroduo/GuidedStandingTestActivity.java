package com.example.electroduo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.interpretingVJ.ECGGraphView;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Bio.Library.namespace.BioLib;

public class GuidedStandingTestActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT = 1; // Request code for enabling Bluetooth
    private String address, macaddress= "", mConnectedDeviceName = "", deviceId = "", accConf = "", textACC;
    private BioLib lib = null;
    private ScrollView scrollView;
    private BluetoothDevice deviceToConnect;
    private TextView lblStatus, textECG, textPULSE, textBAT,  textHR, textDeviceId;
    private ProgressBar progressBar;
    private ConstraintLayout test, stepOne, stepTwo, stepThree, stepFour;
    private Button nextStepButton, buttonStartTest, buttonConnect, buttonDisconnect;
    public static final String DEVICE_NAME = "device_name", TOAST = "toast";
    private ECGGraphView ecgGraphView;
    private List<Float> ecgData = new ArrayList<>();
    private int BATTERY_LEVEL = 0, PULSE = 0, nBytes = 0;
    private BioLib.DataACC dataACC = null;
    private byte accSensibility = 1, typeRadioEvent = 0;	// NOTE: 2G= 0, 4G= 1
    private byte[] infoRadioEvent = null;
    private byte[][] ecg = null;
    private boolean isConn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_guided_test);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Link UI elements for initial instructions
        lblStatus = findViewById(R.id.lblStatus);
        buttonConnect = findViewById(R.id.buttonConnect);
        buttonStartTest = findViewById(R.id.buttonStartTest);
        test = findViewById(R.id.test);
        scrollView = findViewById(R.id.scrollView100);

        textBAT = (TextView) findViewById(R.id.lblBAT);
        textHR = (TextView) findViewById(R.id.lblHR);
        textECG = (TextView) findViewById(R.id.lblECG);
        ecgGraphView = findViewById(R.id.ecgGraphView);

        //From VJ code
        address = "00:23:FE:00:0B:23";
        lblStatus.setText("");

        try
        {
            lib = new BioLib(this, mHandler);
            lblStatus.append("Init BioLib \n");
        }
        catch (Exception e)
        {
            lblStatus.append("Error to init BioLib \n");
            e.printStackTrace();
        }

        buttonConnect = (Button) findViewById(R.id.buttonConnect);
        buttonConnect.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                Connect();
            }

            /***
             * Connect to device.
             */
            private void Connect()
            {
                try
                {
                    deviceToConnect =  lib.mBluetoothAdapter.getRemoteDevice(address);

                    Reset();

                    lblStatus.setText("");
                    lib.Connect(address, 5);
                } catch (Exception e)
                {
                    lblStatus.setText("Error to connect device: " + address);
                    e.printStackTrace();
                }
            }

        });

        // Set Start button to change view to show ECG data
        buttonStartTest.setOnClickListener(new View.OnClickListener() {
            //start another activity
            @Override
            public void onClick(View v) {
                startTest();
            }
        });

        buttonDisconnect = (Button) findViewById(R.id.buttonDisconnect);
        buttonDisconnect.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                Disconnect();
            }
        });
    }

    private void startTest(){
        scrollView.setVisibility(View.GONE);
        test.setVisibility(View.VISIBLE);
    }

    /**
     * The Handler that gets information back from the BioLib
     */
    @SuppressLint("HandlerLeak")
    private final Handler mHandler = new Handler()
    {
        @SuppressLint("MissingPermission")
        @Override
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
/*                case BioLib.MESSAGE_READ:
                    textDataReceived.setText("RECEIVED: " + msg.arg1);
                    break;*/

                case BioLib.MESSAGE_DEVICE_NAME:
                    mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                    Toast.makeText(getApplicationContext(), "Connected to " + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                    lblStatus.append("Connected to " + mConnectedDeviceName + " \n");
                    break;

                case BioLib.MESSAGE_BLUETOOTH_NOT_SUPPORTED:
                    Toast.makeText(getApplicationContext(), "Bluetooth NOT supported. Aborting! ", Toast.LENGTH_SHORT).show();
                    lblStatus.append("Bluetooth NOT supported. Aborting! \n");
                    isConn = false;
                    break;

                case BioLib.MESSAGE_BLUETOOTH_ENABLED:
                    Toast.makeText(getApplicationContext(), "Bluetooth is now enabled! ", Toast.LENGTH_SHORT).show();
                    lblStatus.append("Bluetooth is now enabled \n");
                    lblStatus.append("Macaddress selected: " + address + " \n");
                    buttonConnect.setEnabled(true);
                    break;

                case BioLib.MESSAGE_BLUETOOTH_NOT_ENABLED:
                    Toast.makeText(getApplicationContext(), "Bluetooth not enabled! ", Toast.LENGTH_SHORT).show();
                    lblStatus.append("Bluetooth not enabled \n");
                    isConn = false;
                    break;

                case BioLib.REQUEST_ENABLE_BT:
                    Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableIntent, BioLib.REQUEST_ENABLE_BT);
                    lblStatus.append("Request bluetooth enable \n");
                    break;

                case BioLib.STATE_CONNECTING:
                    lblStatus.append("   Connecting to device ... \n");
                    break;

                case BioLib.STATE_CONNECTED:
                    Toast.makeText(getApplicationContext(), "Connected to " + deviceToConnect.getName(), Toast.LENGTH_SHORT).show();
                    lblStatus.append("   Connect to " + deviceToConnect.getName() + " \n");
                    isConn = true;

                    buttonConnect.setEnabled(false);
                    buttonDisconnect.setEnabled(true);

                    break;

                case BioLib.UNABLE_TO_CONNECT_DEVICE:
                    Toast.makeText(getApplicationContext(), "Unable to connect device! ", Toast.LENGTH_SHORT).show();
                    lblStatus.append("   Unable to connect device \n");
                    isConn = false;

                    buttonConnect.setEnabled(true);
                    buttonDisconnect.setEnabled(false);

                    break;

                case BioLib.MESSAGE_DISCONNECT_TO_DEVICE:
                    Toast.makeText(getApplicationContext(), "Device connection was lost", Toast.LENGTH_SHORT).show();
                    lblStatus.append("   Disconnected from " + deviceToConnect.getName() + " \n");
                    isConn = false;

                    buttonConnect.setEnabled(true);
                    buttonDisconnect.setEnabled(false);

                    break;

                case BioLib.MESSAGE_DATA_UPDATED:
                    BioLib.Output out = (BioLib.Output)msg.obj;
                    BATTERY_LEVEL = out.battery;
                    textBAT.setText("Device Battery Level: " + BATTERY_LEVEL + " %");
                    PULSE = out.pulse;
                    textPULSE.setText("Heart rate: " + PULSE + " bpm");
                    break;

                case BioLib.MESSAGE_ACC_SENSIBILITY:
                    accSensibility = (byte)msg.arg1;
                    accConf = "4G";
                    switch (accSensibility)
                    {
                        case 0:
                            accConf = "2G";
                            break;

                        case 1:
                            accConf = "4G";
                            break;
                    }

                    textACC = "ACC [" + accConf + "]:  X: " + dataACC.X + "  Y: " + dataACC.Y + "  Z: " + dataACC.Z;
                    break;

                case BioLib.MESSAGE_PEAK_DETECTION:
                    BioLib.QRS qrs = (BioLib.QRS)msg.obj;
                    textHR.setText("PEAK: " + qrs.position + "  BPMi: " + qrs.bpmi + " bpm  BPM: " + qrs.bpm + " bpm  R-R: " + qrs.rr + " ms");
                    break;

                case BioLib.MESSAGE_ACC_UPDATED:
                    dataACC = (BioLib.DataACC)msg.obj;

                    if (accConf == "")
                        textACC = "ACC:  X: " + dataACC.X + "  Y: " + dataACC.Y + "  Z: " + dataACC.Z;
                    else
                        textACC = "ACC [" + accConf + "]:  X: " + dataACC.X + "  Y: " + dataACC.Y + "  Z: " + dataACC.Z;

                    break;

                case BioLib.MESSAGE_ECG_STREAM:
                    try
                    {
                        textECG.setText("ECG received");
                        byte[][] ecg = (byte[][]) msg.obj;
                        byte[] singleLead = ecg[0];
                        List<Float> ecgData = new ArrayList<>();
                        for (byte value : singleLead) {
                            ecgData.add((float) value); // Conversión básica
                        }
                        ecgGraphView.setData(ecgData);
                        textECG.setText("Single lead data extracted. Total points: " + singleLead.length);
                        int nLeads = ecg.length;
                        nBytes = ecg[0].length;
                    }
                    catch (Exception ex)
                    {
                        textECG.setText("ERROR in ecg stream");
                    }
                    break;

                case BioLib.MESSAGE_TOAST:
                    Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST), Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    /*
     *
     */

    private void Disconnect()
    {
        try
        {
            lib.Disconnect();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            Reset();
        }
    }


    private void Reset()
    {
        try
        {
            textBAT.setText("Device battery level: - - %");
            textPULSE.setText("PULSE: - - bpm");
            textECG.setText("Ecg stream: -- ");
            textPULSE.setText("Heart rate: -- bpm     Nb. Leads: -- ");
            BATTERY_LEVEL = 0;
            PULSE = 0;
            accConf = "";
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode)
        {
            case BioLib.REQUEST_ENABLE_BT:
                if (resultCode == Activity.RESULT_OK)
                {
                    Toast.makeText(getApplicationContext(), "Bluetooth is now enabled! ", Toast.LENGTH_SHORT).show();
                    lblStatus.append("Bluetooth is now enabled \n");

                    buttonConnect.setEnabled(true);
                    buttonDisconnect.setEnabled(false);

                    lblStatus.append("Macaddress selected: " + address + " \n");
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Bluetooth not enabled! ", Toast.LENGTH_SHORT).show();
                    lblStatus.append("Bluetooth not enabled \n");
                    isConn = false;

                    buttonConnect.setEnabled(false);
                    buttonDisconnect.setEnabled(false);
                }
                break;

            /*case 0:
                switch (resultCode)
                {
                    case SearchDeviceActivity.CHANGE_MACADDRESS:
                        try
                        {
                            lblStatus.append("\nSelect new macaddress: ");
                            macaddress = data.getExtras().getString(SearchDeviceActivity.SELECT_DEVICE_ADDRESS);
                            Toast.makeText(getApplicationContext(), macaddress, Toast.LENGTH_SHORT).show();

                            lblStatus.append(macaddress);

                            address = macaddress;
                        }
                        catch (Exception ex)
                        {
                            Toast.makeText(getApplicationContext(), "ERROR: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        break;
                }
                break;*/
        }
    }

    protected void onDestroy()
    {
        super.onDestroy();

        if (lib.mBluetoothAdapter != null)
        {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            lib.mBluetoothAdapter.cancelDiscovery();
        }

        lib = null;
    }
}
