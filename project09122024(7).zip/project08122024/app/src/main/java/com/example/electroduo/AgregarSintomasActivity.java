package com.example.electroduo;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AgregarSintomasActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private EditText editTextSintomas;
    private ProgressBar progressBar;
    private Button buttonAgregarSintomas;
    private String patientId; // ID del paciente
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_agregar_sintomas);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        dbHelper = new DatabaseHelper(this);
        progressBar = findViewById(R.id.progressBarEnvio);
        editTextSintomas = findViewById(R.id.editTextSintomas);
        buttonAgregarSintomas = findViewById(R.id.buttonAgregarSintomas);
        // Obtener el ID del paciente desde el Intent
        patientId = getIntent().getStringExtra("patient_id");
        if (patientId == null) {
            Toast.makeText(this, "Error: Patient ID not received", Toast.LENGTH_SHORT).show();
            finish(); // Cerrar la actividad si no hay ID
            return;
        }
        buttonAgregarSintomas.setOnClickListener(v -> saveSymptoms());
    }
    private void saveSymptoms() {
        String symptoms = editTextSintomas.getText().toString().trim(); // Obtener y limpiar el texto

        if (!symptoms.isEmpty()) {
            // Mostrar la barra de progreso y desactivar el botón
            progressBar.setVisibility(View.VISIBLE);
            buttonAgregarSintomas.setEnabled(false);

            // Simular un retraso para "enviar" los datos
            new Thread(() -> {
                try {
                    // Simular un proceso de guardar los síntomas (esto debe ser reemplazado por tu lógica)
                    for (int progress = 0; progress <= 100; progress++) {
                        Thread.sleep(30); // Simula un retardo
                        int finalProgress = progress;
                        runOnUiThread(() -> progressBar.setProgress(finalProgress)); // Actualiza la barra de progreso
                    }

                    // Aquí va la lógica real para guardar los síntomas en la base de datos
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    ContentValues values = new ContentValues();

                    // Obtener la fecha y hora actual
                    String fechaHora = getCurrentDateTime();
                    // Formatear el mensaje para incluir el síntoma y la fecha/hora
                    String mensajeConFecha = symptoms + " (" + fechaHora + ")";

                    // Obtener los síntomas actuales
                    String currentSymptoms = dbHelper.getSymptomsByPatientId(patientId);
                    String updatedSymptoms;

                    if (currentSymptoms != null && !currentSymptoms.isEmpty()) {
                        // Concatenar los nuevos síntomas con los existentes
                        updatedSymptoms = currentSymptoms + "\n" + mensajeConFecha; // Usar \n para el historial
                    } else {
                        updatedSymptoms = mensajeConFecha; // Si no hay síntomas previos
                    }

                    values.put(DatabaseHelper.COLUMN_SINTOMAS, updatedSymptoms);

                    // Actualizar los síntomas del paciente
                    int rowsAffected = db.update(DatabaseHelper.TABLE_USERS, values,
                            DatabaseHelper.COLUMN_ID + "=?", new String[]{patientId});

                    // Ocultar la barra de progreso y habilitar el botón
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        buttonAgregarSintomas.setEnabled(true);

                        if (rowsAffected > 0) {
                            Toast.makeText(AgregarSintomasActivity.this, "Symptoms sent successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(AgregarSintomasActivity.this, "Error saving symptoms", Toast.LENGTH_SHORT).show();
                        }

                        finish(); // Cerrar la actividad
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        } else {
            Toast.makeText(this, "Please enter symptoms", Toast.LENGTH_SHORT).show();
        }
    }
    // Método para obtener la fecha y hora actual
    private String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }
}