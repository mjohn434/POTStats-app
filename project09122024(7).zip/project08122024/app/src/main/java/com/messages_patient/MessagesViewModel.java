package com.messages_patient;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.electroduo.DatabaseHelper;

public class MessagesViewModel extends ViewModel {

    private final MutableLiveData<String[]> messages;
    private DatabaseHelper dbHelper;

    public MessagesViewModel() {
        messages = new MutableLiveData<>();
    }

    public void initDatabaseHelper(Context context) {
        dbHelper = new DatabaseHelper(context);  // Initialize the DatabaseHelper with context
    }

    public LiveData<String[]> getMessages(String patientId) {
        loadMessages(patientId);
        return messages;
    }

    private void loadMessages(String patientId) {
        String rawMessages = dbHelper.getMessagesByPatientId(patientId);
        if (rawMessages != null && !rawMessages.isEmpty()) {
            String[] messageArray = rawMessages.split("\n"); // Split messages by newline
            messages.setValue(messageArray);
        } else {
            messages.setValue(new String[]{"When your doctor sends a message it will appear here."});
        }
    }
}