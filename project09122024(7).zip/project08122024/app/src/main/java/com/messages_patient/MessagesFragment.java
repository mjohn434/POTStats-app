package com.messages_patient;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.electroduo.DatabaseHelper;
import com.example.electroduo.MainActivity;
import com.example.electroduo.R;
import com.example.electroduo.databinding.FragmentMessagesBinding;

public class MessagesFragment extends Fragment {
    private ListView listViewMensajes;
    private FragmentMessagesBinding binding;
    private MessagesViewModel messagesViewModel;
    private Button buttonOut;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        // Initialize ViewModel
        messagesViewModel = new ViewModelProvider(this).get(MessagesViewModel.class);

        // Initialize ViewBinding
        binding = FragmentMessagesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Initialize ListView from binding
        listViewMensajes = binding.listViewMensajes;

        // Get patient ID
        String patientId = getActivity().getIntent().getStringExtra("id");

        // Pass the context to ViewModel for database initialization
        messagesViewModel.initDatabaseHelper(getContext());

        // Observe the messages from ViewModel
        messagesViewModel.getMessages(patientId).observe(getViewLifecycleOwner(), messages -> {
            // Create an adapter to display the messages
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, messages);
            listViewMensajes.setAdapter(adapter);
        });

        buttonOut = binding.buttonOut;
        buttonOut.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), MainActivity.class);
            startActivity(intent);
            getActivity().finish();
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}