package com.symtoms_patient;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.electroduo.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class SymptomsViewModel extends ViewModel {


    private final MutableLiveData<List<String>> symptoms;

    private DatabaseHelper dbHelper;


    public SymptomsViewModel() {

        symptoms = new MutableLiveData<>();

    }


    public void initDatabaseHelper(Context context) {

        dbHelper = new DatabaseHelper(context);  // Inicializar el DatabaseHelper con el contexto

    }


    public LiveData<List<String>> getSymptoms(String patientId) {

        loadSymptoms(patientId);

        return symptoms;

    }


    private void loadSymptoms(String patientId) {

        String rawSymptoms = dbHelper.getSymptomsByPatientId(patientId);

        List<String> symptomList = new ArrayList<>();


        if (rawSymptoms != null && !rawSymptoms.isEmpty()) {

            String[] symptomArray = rawSymptoms.split(","); // Suponiendo que los síntomas están separados por comas

            for (String symptom : symptomArray) {

                symptomList.add(symptom.trim());

            }

        } else {

            symptomList.add("No symptoms have been registered yet.");

        }


        symptoms.setValue(symptomList);

    }

}