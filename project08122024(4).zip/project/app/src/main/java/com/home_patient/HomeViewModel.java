package com.home_patient;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

   /* private final MutableLiveData<String> mNombre = new MutableLiveData<>();
    private final MutableLiveData<String> mId = new MutableLiveData<>();*/

    private String mNombre = new String();
    private String mId = new String();


    public void setNombre(String nombre) {
        // Setter for 'nombre'
        if (nombre != null) {
            mNombre = nombre;;
        }
        else{
            mNombre = "No name";
        }
    }

    public void setId(String id) {
        if (id != null) {
            mId = id;;
        }else{
            mId = "No id";
        }
    }

    public String getNombre() {
        return mNombre;
    }

    public String getId() {
        return mId;
    }
}
