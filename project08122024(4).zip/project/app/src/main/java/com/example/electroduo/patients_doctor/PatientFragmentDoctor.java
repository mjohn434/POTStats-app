package com.example.electroduo.patients_doctor;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.electroduo.DatabaseHelper;
import com.example.electroduo.MainActivity;
import com.example.electroduo.Pinfo;
import com.example.electroduo.Usuario;
import com.example.electroduo.databinding.FragmentPatientDoctorBinding;

import java.util.List;

public class PatientFragmentDoctor extends Fragment {

    private FragmentPatientDoctorBinding binding;
    private PatientsViewModel patientsViewModel;
    private DatabaseHelper dbHelper;
    private String selectedPatientId;
    private TextView textViewSL;
    private Button buttonOut, buttonVerSintomas,buttonVerInfoPaciente,buttonEnviarMensaje, buttonViewTestResults, buttonSendMessage;
    private Spinner spinnerPacientes;
    private LinearLayout linearLayoutSymptoms, linearLayoutMessages, linearLayoutTest, linearLayoutMedicalHistory;
    private List<Usuario> pacientes; // Lista de usuarios (pacientes)
    private EditText editTextMessage; // Agrega esto en tu clase DOCTOR

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        //patientsViewModel = new ViewModelProvider(requireActivity()).get(PatientsViewModel.class); // Getting the same ViewModel

        binding = FragmentPatientDoctorBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Bind views
        spinnerPacientes = binding.spinnerPacientes;
        textViewSL = binding.textViewSL;
        editTextMessage = binding.editTextMessage;
        buttonOut = binding.buttonOut;
        buttonVerSintomas = binding.buttonVerSintomas;
        buttonVerInfoPaciente = binding.buttonVerInfoPaciente;
        buttonViewTestResults = binding.buttonViewTestResults;
        buttonEnviarMensaje = binding.buttonEnviarMensaje;
        buttonSendMessage = binding.buttonSendMessage;
        dbHelper = new DatabaseHelper(requireContext());
        linearLayoutSymptoms = binding.linearLayoutSymptoms;
        linearLayoutMessages = binding.linearLayoutMessages;
        linearLayoutTest = binding.linearLayoutTest;
        linearLayoutMedicalHistory =binding.linearLayoutMedicalHistory;

        //Load Doctor's patients
        String doctorId = requireActivity().getIntent().getStringExtra("doctorId");
        loadPatients(doctorId);

        //Configure log out Button
        buttonOut.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), MainActivity.class);
            startActivity(intent);
            getActivity().finish();
        });

        // Configure button for viewing test results
        buttonViewTestResults.setOnClickListener(view -> {
            linearLayoutSymptoms.setVisibility(View.GONE);
            linearLayoutMessages.setVisibility(View.GONE);
            linearLayoutTest.setVisibility(View.VISIBLE);
            linearLayoutMedicalHistory.setVisibility(View.GONE);
            buttonSendMessage.setVisibility(View.VISIBLE);

            if (selectedPatientId != null) {
                // Get test results - ECG etc.
                Toast.makeText(requireContext(), "This will be updated", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "Please select a patient.", Toast.LENGTH_SHORT).show();
            }
        });


        // Configure button for viewing symptoms
        buttonVerSintomas.setOnClickListener(view -> {
            linearLayoutSymptoms.setVisibility(View.VISIBLE);
            linearLayoutMessages.setVisibility(View.GONE);
            linearLayoutTest.setVisibility(View.GONE);
            linearLayoutMedicalHistory.setVisibility(View.GONE);
            buttonSendMessage.setVisibility(View.VISIBLE);

            if (selectedPatientId != null) {
                // Obtener los síntomas del paciente seleccionado
                String sintomas = dbHelper.getSymptomsByPatientId(selectedPatientId);
                if (sintomas != null && !sintomas.isEmpty()) {
                    textViewSL.setText(sintomas); // Mostrar los síntomas en el TextView
                } else {
                    textViewSL.setText("No symptoms have been registered yet");
                }
            } else {
                Toast.makeText(requireContext(), "Please select a patient.", Toast.LENGTH_SHORT).show();
            }
        });

        // Configure button for viewing patient information
        buttonVerInfoPaciente.setOnClickListener(view -> {
            linearLayoutSymptoms.setVisibility(View.GONE);
            linearLayoutMessages.setVisibility(View.GONE);
            linearLayoutTest.setVisibility(View.GONE);
            linearLayoutMedicalHistory.setVisibility(View.VISIBLE);
            buttonSendMessage.setVisibility(View.VISIBLE);

            Pinfo pinfoView = binding.pinfoView;
            if (selectedPatientId != null) {
                Usuario paciente = dbHelper.getPatientById(selectedPatientId);
                if (paciente != null) {
                    pinfoView.setPatientData(paciente);
                    linearLayoutMedicalHistory.setVisibility(View.VISIBLE);
                } else {
                    Toast.makeText(requireContext(), "Patient not found.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(requireContext(), "Please select a patient.", Toast.LENGTH_SHORT).show();
            }
        });

        // Configure button for toggling forward the sending message function
        buttonSendMessage.setOnClickListener(view -> {
            linearLayoutSymptoms.setVisibility(View.GONE);
            linearLayoutMessages.setVisibility(View.VISIBLE);
            linearLayoutTest.setVisibility(View.GONE);
            linearLayoutMedicalHistory.setVisibility(View.GONE);
            buttonSendMessage.setVisibility(View.GONE);
        });

        //Configure button to send message to patient
        buttonEnviarMensaje.setOnClickListener(view -> {
            String message = editTextMessage.getText().toString().trim();
            if (!message.isEmpty() && selectedPatientId != null) {
                // Add message to Database helper
                dbHelper.addMessage(selectedPatientId, message);
                editTextMessage.setText(""); // Limpiar el campo de texto
                Toast.makeText(requireContext(), "Message sent.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireContext(), "Please write a message.", Toast.LENGTH_SHORT).show();
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // Code for loading the spinner with patient names
    private void loadPatients(String doctorId) {
        pacientes = dbHelper.getAllPatients(doctorId); // Obtener pacientes relacionados con el doctor
        ArrayAdapter<Usuario> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, pacientes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPacientes.setAdapter(adapter);
        spinnerPacientes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                linearLayoutSymptoms.setVisibility(View.GONE);
                linearLayoutMessages.setVisibility(View.GONE); //not used right now
                linearLayoutTest.setVisibility(View.GONE);
                linearLayoutMedicalHistory.setVisibility(View.GONE);
                buttonSendMessage.setVisibility(View.VISIBLE);
                selectedPatientId = pacientes.get(position).getId(); // Obtener el ID del paciente seleccionado
                textViewSL.setText(""); // Restablecer el mensaje de síntomas
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedPatientId = null;
                textViewSL.setText("No symptoms have been added."); // Restablecer el mensaje de síntomas
            }
        });
    }
}