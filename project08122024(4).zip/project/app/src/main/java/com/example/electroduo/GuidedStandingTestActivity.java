package com.example.electroduo;

import android.bluetooth.BluetoothAdapter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class GuidedStandingTestActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT = 1; // Request code for enabling Bluetooth
    private BluetoothAdapter bluetoothAdapter;
    private TextView instruction1, instruction2;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_guided_test);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Bluetooth Adapter
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not supported on this device", Toast.LENGTH_LONG).show();
            finish();
        }

        // Link UI elements
        TextView instructionOne = findViewById(R.id.instruction1);
        TextView instructionTwo = findViewById(R.id.instruction2);
        Button nextStepButton = findViewById(R.id.buttonNext);
        progressBar = findViewById(R.id.progressBar);

        // Set button click listener to interact with GuidedStandingTest logic
        nextStepButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performNextStep();
            }
        });

        // Initialize progress bar
        initializeUI();
    }

    private void initializeUI() {
        // Example: Set the initial progress
        progressBar.setProgress(0);
    }

    private void performNextStep() {
        // Example: Increment progress bar and update instructions
        int progress = progressBar.getProgress() + 25;
        if (progress <= 100) {
            progressBar.setProgress(progress);
        }

        if (progress==25){
            instruction1.setText("Step 2");
        }else if (progress==50){
            instruction1.setText("Step 2");
        }else if (progress==75){
            instruction1.setText("Step 2");
        }
    }
}
