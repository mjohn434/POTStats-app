package com.example.electroduo.patients_doctor;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class PatientsViewModel extends PatientFragmentDoctor{
    private final MutableLiveData<String> mText;

    public PatientsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is the patient fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
