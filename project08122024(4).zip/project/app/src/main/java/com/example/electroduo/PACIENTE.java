package com.example.electroduo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.electroduo.databinding.ActivityPacienteBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.example.electroduo.databinding.ActivityMainBinding;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PACIENTE extends AppCompatActivity {
    /*private Button buttonOut;
    private TextView textViewN;
    private Button buttonAgregarSintomas;
    private Button buttonVerMensajes;
    private Button buttonEditarInfo;*/
    private ActivityPacienteBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityPacienteBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set the Toolbar as the ActionBar
        setSupportActionBar(binding.toolbar);

        EdgeToEdge.enable(this);
        //COMMENTED OUT setContentView(R.layout.activity_paciente);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.container_pat), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Setup bottom navigation and NavController
        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_test, R.id.navigation_messages, R.id.navigation_symptoms).build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);


        /* textViewN = findViewById(R.id.textViewN); // Asegúrate de tener este TextView en tu layout
        String nombre = getIntent().getStringExtra("nombre");
        if (nombre != null) {
            textViewN.setText(nombre); // Muestra el nombre del paciente
        }
        buttonAgregarSintomas = findViewById(R.id.buttonAgregarSintomas); // Inicializar el nuevo botón
        buttonAgregarSintomas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navegar a la actividad de agregar síntomas
                Intent intent = new Intent(PACIENTE.this, AgregarSintomasActivity.class);
                intent.putExtra("patient_id", getIntent().getStringExtra("id")); // Pasar el ID del paciente
                startActivity(intent);
            }
        });

        // Navegar a la actividad de ver mensajes
        buttonVerMensajes = findViewById(R.id.buttonVerMensajes);
        buttonVerMensajes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PACIENTE.this, DPactivity.class);
                intent.putExtra("id", getIntent().getStringExtra("id")); // Pasar el ID del paciente
                startActivity(intent);
            }
        });


        // Navegar al HUB
        buttonOut = findViewById(R.id.buttonOut);
        buttonOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PACIENTE.this, MainActivity.class);
                startActivity(intent);
                finish(); // Opcional: cierra la actividad actual
            }
        });

        // Navegar a MIS DATOS
        buttonEditarInfo = findViewById(R.id.Myinfo);
        buttonEditarInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PACIENTE.this, EditarInfoActivity.class);
                intent.putExtra("id", getIntent().getStringExtra("id")); // Pasar el ID del paciente
                startActivity(intent);
            }
        });*/
    }
}
