package com.example.electroduo;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import android.widget.EditText;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;

import com.home_patient.HomeViewModel;

public class MainActivity extends AppCompatActivity {
    private EditText editTextUsername, editTextPassword;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_main);
        dbHelper = new DatabaseHelper(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(view -> {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }
            Usuario user = dbHelper.checkUser (username, password);
            if (user != null) {
                // Redirigir según el tipo de usuario
                Intent intent;
                if (user.getType().equalsIgnoreCase("DOCTOR")) {
                    intent = new Intent(MainActivity.this, DOCTOR.class);
                    intent.putExtra("nombre", user.getNombre());
                    intent.putExtra("id", user.getId());
                    intent.putExtra("doctorId", user.getDoctorId()); // Asegúrate de que doctorId tenga el valor correcto// Enviar el nombre del doctor
                } else if (user.getType().equalsIgnoreCase("PACIENTE")) {
                    intent = new Intent(MainActivity.this, PACIENTE.class);
                    intent.putExtra("nombre", user.getNombre());
                    intent.putExtra("id", user.getId());
                    intent.putExtra("doctorId", user.getDoctorId()); // Enviar el nombre del paciente
                    Log.d("Tag", "Name of patient: " + user.getNombre());

                } else {
                    Toast.makeText(MainActivity.this, "User type not recognized", Toast.LENGTH_SHORT).show();
                    return; // En caso de que el tipo no sea reconocido, no hacer nada
                }
                startActivity(intent);
                finish(); // Opcional: cierra la actividad actual
            } else {
                Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });
    }
}