package com.example.electroduo;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditarInfoActivity extends AppCompatActivity {
    private EditText editTextNombre;
    private EditText editTextEdad;
    private EditText editTextTelefono;
    private EditText editTextNumeroHistorial;
    private Spinner spinnerGenero;
    private EditText editTextHeight;
    private EditText editTextWeight;
    private EditText editTextMedications;
    private EditText editTextDiagnoses;
    private Button buttonGuardar;
    private DatabaseHelper databaseHelper;
    private String patientId; // ID del paciente// Instancia de DatabaseHelper
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editar_info);
        // Inicializar los EditText y el Button
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextEdad = findViewById(R.id.editTextEdad);
        editTextTelefono = findViewById(R.id.editTextTelefono);
        editTextNumeroHistorial = findViewById(R.id.editTextNumeroHistorial);
        spinnerGenero = findViewById(R.id.spinnerGenero);
        editTextHeight = findViewById(R.id.editTextHeight); // Nueva línea
        editTextWeight = findViewById(R.id.editTextWeight); // Nueva línea
        editTextMedications = findViewById(R.id.editTextMedications); // Nueva línea
        editTextDiagnoses = findViewById(R.id.editTextDiagnoses);
        buttonGuardar = findViewById(R.id.buttonGuardar);
        databaseHelper = new DatabaseHelper(this);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.genero_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGenero.setAdapter(adapter);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        patientId = getIntent().getStringExtra("id");
        if (patientId == null) {
            Toast.makeText(this, "Error: Patient ID not received", Toast.LENGTH_SHORT).show();
            finish(); // Cerrar la actividad si no hay ID
            return;
        }
        Usuario paciente = databaseHelper.getPatientById(patientId);

        if (paciente != null) {
            // Llenar los campos con la información del paciente
            editTextNombre.setText(paciente.getNombre());
            editTextEdad.setText(String.valueOf(paciente.getAge())); // Asegúrate de que el método getAge() exista
            editTextTelefono.setText(paciente.getPhoneNumber());
            editTextNumeroHistorial.setText(paciente.getMedicalRecordNumber());
            editTextHeight.setText(String.valueOf(paciente.getHeight()));
            editTextWeight.setText(String.valueOf(paciente.getWeight()));
            editTextMedications.setText(paciente.getMedications());
            editTextDiagnoses.setText(paciente.getDiagnoses());
            // Establecer el género en el Spinner
            int spinnerPosition = adapter.getPosition(paciente.getGender());
            spinnerGenero.setSelection(spinnerPosition);
        } else {
            Toast.makeText(this, "Error: Patient not found", Toast.LENGTH_SHORT).show();
            finish(); // Cerrar la actividad si no se encuentra el paciente
        }
        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener los valores de los EditText
                String nombre = editTextNombre.getText().toString();
                String edad = editTextEdad.getText().toString();
                String telefono = editTextTelefono.getText().toString();
                String numeroHistorial = editTextNumeroHistorial.getText().toString();
                String genero = spinnerGenero.getSelectedItem().toString();
                String heightStr = editTextHeight.getText().toString(); // Obtener altura
                String weightStr = editTextWeight.getText().toString(); // Obtener peso
                String medications = editTextMedications.getText().toString(); // Obtener medicamentos
                String diagnoses = editTextDiagnoses.getText().toString(); // Obtener diagnósticos
                // Validar que todos los campos estén llenos
                if (nombre.isEmpty() || edad.isEmpty() || telefono.isEmpty() || numeroHistorial.isEmpty() || genero.isEmpty() || heightStr.isEmpty() || weightStr.isEmpty() || medications.isEmpty() || diagnoses.isEmpty()) {
                    Toast.makeText(EditarInfoActivity.this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Convertir altura y peso a float
                    float height = Float.parseFloat(heightStr);
                    float weight = Float.parseFloat(weightStr);
                    // Llamar al método updatePatient
                    databaseHelper.updatePatient(patientId, nombre, Integer.parseInt(edad), telefono, numeroHistorial, genero, height, weight, medications, diagnoses);
                    Toast.makeText(EditarInfoActivity.this, "Saved information", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}