package com.example.electroduo;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pinfo extends AppCompatActivity {
    private TextView textViewId;
    private TextView textViewNombre;
    private TextView textViewEdad;
    private TextView textViewTelefono;
    private TextView textViewNumeroHistorial;
    private TextView textViewGenero;
    private TextView textViewHeight; // Nueva línea
    private TextView textViewWeight; // Nueva línea
    private TextView textViewMedications; // Nueva línea
    private TextView textViewDiagnoses; // Nueva línea

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pinfo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        textViewId = findViewById(R.id.textViewId);
        textViewNombre = findViewById(R.id.textViewNombre);
        textViewEdad = findViewById(R.id.textViewEdad);
        textViewTelefono = findViewById(R.id.textViewTelefono);
        textViewNumeroHistorial = findViewById(R.id.textViewNumeroHistorial);
        textViewGenero = findViewById(R.id.textViewGenero);
        textViewHeight = findViewById(R.id.textViewHeight); // Nueva línea
        textViewWeight = findViewById(R.id.textViewWeight); // Nueva línea
        textViewMedications = findViewById(R.id.textViewMedications); // Nueva línea
        textViewDiagnoses = findViewById(R.id.textViewDiagnoses);
        Usuario paciente = (Usuario) getIntent().getSerializableExtra("paciente");
        if (paciente != null) {
            textViewId.setText("ID: " + paciente.getId());
            textViewNombre.setText("Name: " +paciente.getNombre());
            textViewEdad.setText("Age: " + String.valueOf(paciente.getAge()));
            textViewTelefono.setText("Telephone Number: " +paciente.getPhoneNumber());
            textViewNumeroHistorial.setText("Medical Record Number: " +paciente.getMedicalRecordNumber());
            textViewGenero.setText("Gender: " +paciente.getGender());
            textViewHeight.setText("Height: " + paciente.getHeight() + " m"); // Asumiendo que la altura está en metros
            textViewWeight.setText("Weight: " + paciente.getWeight() + " kg"); // Asumiendo que el peso está en kilogramos
            textViewMedications.setText("Medications: " + paciente.getMedications());
            textViewDiagnoses.setText("Diagnostics: " + paciente.getDiagnoses());
        }
    }
}