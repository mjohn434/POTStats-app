package com.example.electroduo;
import java.io.Serializable;

public class Usuario implements Serializable {
    private String id;         // ID del usuario
    private String password;   // Contraseña del usuario
    private String type;       // Tipo de usuario (ej. DOCTOR, PACIENTE)
    private String nombre;     // Nombre del usuario
    private String sintomas;   // Síntomas del paciente
    private String doctorId;   // ID del doctor
    private String messages;    // Mensajes del usuario
    private int age;           // Edad del paciente
    private String phoneNumber; // Número de teléfono
    private String medicalRecordNumber; // Número de historial médico
    private String gender;      // Género
    private float height; // Altura
    private float weight; // Peso
    private String medications; // Medicamentos
    private String diagnoses; // Diagnósticos

    // Constructor actualizado
    public Usuario(String id, String password, String type, String nombre, String sintomas, String doctorId, String messages, int age, String phoneNumber, String medicalRecordNumber, String gender, float height, float weight, String medications, String diagnoses) {
        this.id = id;
        this.password = password;
        this.type = type;
        this.nombre = nombre;
        this.sintomas = sintomas;
        this.doctorId = doctorId;
        this.messages = messages;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.medicalRecordNumber = medicalRecordNumber;
        this.gender = gender;
        this.height = height;
        this.weight = weight;
        this.medications = medications;
        this.diagnoses = diagnoses;
    }

    // Constructor simplificado para el Spinner
    public Usuario(String id, String nombre, String sintomas) {
        this.id = id;
        this.nombre = nombre;
        this.sintomas = sintomas; // Asignar síntomas
        this.type = "PACIENTE"; // Asignar tipo por defecto
        this.doctorId = ""; // Inicializar doctorId
        this.messages = ""; // Inicializar mensajes como vacío
        this.age = 0; // Inicializar edad
        this.phoneNumber = ""; // Inicializar número de teléfono
        this.medicalRecordNumber = ""; // Inicializar número de historial médico
        this.gender = ""; // Inicializar género
    }

    public String toString() {
        return nombre + " (" + id + ")"; // Mostrar el nombre y el ID en el Spinner
    }

    // Getters y Setters
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getType() {
        return type;
    }
    public void setTipo(String tipo) {
        this.type = tipo;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getSintomas() {
        return sintomas;
    }
    public String getUltimoSintoma() {
        if (sintomas != null && !sintomas.isEmpty()) {
            String[] sintomasArray = sintomas.split("\n"); // Divide el String por comas
            return sintomasArray[sintomasArray.length - 1].trim(); // Devuelve el último síntoma, eliminando espacios
        }
        return "No symptoms"; // O cualquier otro valor por defecto
    }
    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }
    public String getDoctorId() {
        return doctorId;
    }
    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }
    public String getMessages() {
        return messages; // Método getter para los mensajes
    }
    public void setMessages(String messages) {
        this.messages = messages; // Método setter para los mensajes
    }


    // Nuevos Getters y Setters
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getMedicalRecordNumber() {
        return medicalRecordNumber;
    }
    public void setMedicalRecordNumber(String medicalRecordNumber) {
        this.medicalRecordNumber = medicalRecordNumber;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public float getHeight() {
        return height;
    }
    public void setHeight(float height) {
        this.height = height;
    }
    public float getWeight() {
        return weight;
    }
    public void setWeight(float weight) {
        this.weight = weight;
    }
    public String getMedications() {
        return medications;
    }
    public void setMedications(String medications) {
        this.medications = medications;
    }
    public String getDiagnoses() {
        return diagnoses;
    }
    public void setDiagnoses(String diagnoses) {
        this.diagnoses = diagnoses;
    }
}