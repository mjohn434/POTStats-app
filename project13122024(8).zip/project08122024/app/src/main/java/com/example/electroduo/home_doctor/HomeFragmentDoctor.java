package com.example.electroduo.home_doctor;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.electroduo.DatabaseHelper;
import com.example.electroduo.MainActivity;
import com.example.electroduo.R;
import com.example.electroduo.Usuario;
import com.example.electroduo.databinding.FragmentHomeDoctorBinding;

import java.util.List;

public class HomeFragmentDoctor extends Fragment {
    private FragmentHomeDoctorBinding binding;
    private TextView textViewNombre;
    private Button buttonOut;
    private RecyclerView recyclerViewPatients;
    private DatabaseHelper databaseHelper; // Asegúrate de tener tu clase de base de datos

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        //homeViewModelDoctor = new ViewModelProvider(requireActivity()).get(HomeViewModelDoctor.class); // Getting the same ViewModel

        binding = FragmentHomeDoctorBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        Log.d("TAG", "I got here");
        databaseHelper = new DatabaseHelper(getContext());
        // Bind views
        textViewNombre = binding.textViewNombre;
        buttonOut = binding.buttonOut;
        recyclerViewPatients = binding.recyclerViewPatients;

        // Update the name of the doctor
        String nombre = requireActivity().getIntent().getStringExtra("nombre");
        if (nombre != null) {
            textViewNombre.setText(nombre); // Muestra el nombre del doctor
        }
        String doctorId = requireActivity().getIntent().getStringExtra("doctorId");
        List<Usuario> patients = databaseHelper.getAllPatients(doctorId);
        recyclerViewPatients.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewPatients.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override
            public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_patient, parent, false);
                return new PatientViewHolder(view);
            }
            @Override
            public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
                Usuario patient = patients.get(position);
                PatientViewHolder patientHolder = (PatientViewHolder) holder;
                patientHolder.textViewPatientId.setText("Patient ID: " + patient.getId()); // Asegúrate de que getId() esté definido en la clase Usuario
                patientHolder.textViewPatientName.setText(patient.getNombre());
                patientHolder.textViewLastSymptom.setText("Last symptom: " + patient.getUltimoSintoma());
            }
            @Override
            public int getItemCount() {
                return patients.size();
            }

            class PatientViewHolder extends RecyclerView.ViewHolder {
                TextView textViewPatientId;
                TextView textViewPatientName;
                TextView textViewLastSymptom;
                public PatientViewHolder(View itemView) {
                    super(itemView);
                    textViewPatientId = itemView.findViewById(R.id.textViewPatientId);
                    textViewPatientName = itemView.findViewById(R.id.textViewPatientName);
                    textViewLastSymptom = itemView.findViewById(R.id.textViewLastSymptom);                }
            }
        });

        // Logout of account
        buttonOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
                getActivity().finish();
                Toast.makeText(requireContext(), "Logged out", Toast.LENGTH_SHORT).show();
            }
        });
        return root;

    }

    //CODE from Jose!!

    /*// Update the name of the doctor
    String nombre = getIntent().getStringExtra("nombre");
    String doctorId = getIntent().getStringExtra("doctorId");
    // Load patient list for that doctor
    loadPatients(doctorId);// Asegúrate de que este ID se pase al iniciar la actividad
        if (nombre != null) {
        textViewNombre.setText(nombre); // Muestra el nombre del doctor
    }


    // Logout of account
    buttonOut = findViewById(R.id.buttonOut);
        buttonOut.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(DOCTOR.this, MainActivity.class);
            startActivity(intent);
            finish(); // Opcional: cierra la actividad actual
        }
    });

    // Configurar el botón de ver sintomas
        buttonVerSintomas.setOnClickListener(view -> {
        if (selectedPatientId != null) {
            // Obtener los síntomas del paciente seleccionado
            String sintomas = dbHelper.getSymptomsByPatientId(selectedPatientId);
            if (sintomas != null && !sintomas.isEmpty()) {
                textViewSL.setText(sintomas); // Mostrar los síntomas en el TextView
            } else {
                textViewSL.setText("");
            }
        } else {
            Toast.makeText(DOCTOR.this, "Please select a patient.", Toast.LENGTH_SHORT).show();
        }
    });

    // Configurar el botón para ver información del paciente
        buttonVerInfoPaciente.setOnClickListener(view -> {
        if (selectedPatientId != null) {
            // Obtener el paciente seleccionado
            Usuario paciente = dbHelper.getPatientById(selectedPatientId);
            if (paciente != null) {
                // Crear un Intent para iniciar la actividad Pinfo
                Intent intent = new Intent(DOCTOR.this, Pinfo.class);
                intent.putExtra("paciente", paciente); // Pasar el objeto paciente
                startActivity(intent);
            } else {
                Toast.makeText(DOCTOR.this, "The patient could not be found.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(DOCTOR.this, "Please select a patient.", Toast.LENGTH_SHORT).show();
        }
    });

    // Configurar el botón para enviar mensaje
        buttonEnviarMensaje.setOnClickListener(view -> {
        String message = editTextMessage.getText().toString().trim();
        if (!message.isEmpty() && selectedPatientId != null) {
            // Llamar al método addMessage del DatabaseHelper
            dbHelper.addMessage(selectedPatientId, message);
            editTextMessage.setText(""); // Limpiar el campo de texto
            Toast.makeText(DOCTOR.this, "Message sent.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(DOCTOR.this, "Please write a message.", Toast.LENGTH_SHORT).show();

        }

    });
        return root;
}*/

//END OF CODE FROM JOSE

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}