package com.example.electroduo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.electroduo.databinding.ActivityDoctorBinding;
import com.example.electroduo.databinding.ActivityPacienteBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

public class DOCTOR extends AppCompatActivity {
    private ActivityDoctorBinding binding;
    /*private TextView textViewNombre;
    private Button buttonOut;
    private Spinner spinnerPacientes;
    private Button buttonVerSintomas;
    private TextView textViewSL; // Añadir el TextView para mostrar síntomas
    private DatabaseHelper dbHelper;
    private List<Usuario> pacientes; // Lista de usuarios (pacientes)
    private String selectedPatientId;
    private EditText editTextMessage; // Agrega esto en tu clase DOCTOR*/

    //@SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDoctorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set the Toolbar as the ActionBar
        setSupportActionBar(binding.toolbar);

        EdgeToEdge.enable(this);
        // COMMENTED OUT setContentView(R.layout.activity_doctor);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.container_doc), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Setup bottom navigation and NavController
        BottomNavigationView navViewDoc = findViewById(R.id.nav_view_doctor);
        AppBarConfiguration appBarConfigurationDoc = new AppBarConfiguration.Builder(
                R.id.doctor_home, R.id.doctor_patients).build();
        NavController navControllerDoc = Navigation.findNavController(this, R.id.nav_host_fragment_doctor);
        NavigationUI.setupActionBarWithNavController(this, navControllerDoc, appBarConfigurationDoc);
        NavigationUI.setupWithNavController(navViewDoc, navControllerDoc);







        /*spinnerPacientes = findViewById(R.id.spinnerPacientes);
        buttonVerSintomas = findViewById(R.id.buttonVerSintomas);
        textViewNombre = findViewById(R.id.textViewNombre);
        textViewSL = findViewById(R.id.textViewSL); // Inicializa el TextView para síntomas
        dbHelper = new DatabaseHelper(this);
        textViewNombre = findViewById(R.id.textViewNombre);
        buttonOut = findViewById(R.id.buttonOut);
        editTextMessage = findViewById(R.id.editTextMessage);
        Button buttonEnviarMensaje = findViewById(R.id.buttonEnviarMensaje);
        Button buttonVerInfoPaciente = findViewById(R.id.buttonVerInfoPaciente);

        // Update the name of the doctor
        String nombre = getIntent().getStringExtra("nombre");
        String doctorId = getIntent().getStringExtra("doctorId");
        // Load patient list for that doctor
        loadPatients(doctorId);// Asegúrate de que este ID se pase al iniciar la actividad
        if (nombre != null) {
            textViewNombre.setText(nombre); // Muestra el nombre del doctor
        }


        // Logout of account
        buttonOut = findViewById(R.id.buttonOut);
        buttonOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DOCTOR.this, MainActivity.class);
                startActivity(intent);
                finish(); // Opcional: cierra la actividad actual
            }
        });

        // Configurar el botón de ver sintomas
        buttonVerSintomas.setOnClickListener(view -> {
            if (selectedPatientId != null) {
                // Obtener los síntomas del paciente seleccionado
                String sintomas = dbHelper.getSymptomsByPatientId(selectedPatientId);
                if (sintomas != null && !sintomas.isEmpty()) {
                    textViewSL.setText(sintomas); // Mostrar los síntomas en el TextView
                } else {
                    textViewSL.setText("");
                }
            } else {
                Toast.makeText(DOCTOR.this, "Please select a patient.", Toast.LENGTH_SHORT).show();
            }
        });

        // Configurar el botón para ver información del paciente
        buttonVerInfoPaciente.setOnClickListener(view -> {
            if (selectedPatientId != null) {
                // Obtener el paciente seleccionado
                Usuario paciente = dbHelper.getPatientById(selectedPatientId);
                if (paciente != null) {
                    // Crear un Intent para iniciar la actividad Pinfo
                    Intent intent = new Intent(DOCTOR.this, Pinfo.class);
                    intent.putExtra("paciente", paciente); // Pasar el objeto paciente
                    startActivity(intent);
                } else {
                    Toast.makeText(DOCTOR.this, "The patient could not be found.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(DOCTOR.this, "Please select a patient.", Toast.LENGTH_SHORT).show();
            }
        });

        // Configurar el botón para enviar mensaje
        buttonEnviarMensaje.setOnClickListener(view -> {
            String message = editTextMessage.getText().toString().trim();
            if (!message.isEmpty() && selectedPatientId != null) {
                // Llamar al método addMessage del DatabaseHelper
                dbHelper.addMessage(selectedPatientId, message);
                editTextMessage.setText(""); // Limpiar el campo de texto
                Toast.makeText(DOCTOR.this, "Message sent.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(DOCTOR.this, "Please write a message.", Toast.LENGTH_SHORT).show();

            }

        });*/
    }
    /*private void loadPatients(String doctorId) {
        pacientes = dbHelper.getAllPatients(doctorId); // Obtener pacientes relacionados con el doctor
        ArrayAdapter<Usuario> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, pacientes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPacientes.setAdapter(adapter);
        spinnerPacientes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedPatientId = pacientes.get(position).getId(); // Obtener el ID del paciente seleccionado
                textViewSL.setText(""); // Restablecer el mensaje de síntomas
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedPatientId = null;
                textViewSL.setText("No symptoms have been added."); // Restablecer el mensaje de síntomas
            }
        });
    }*/

}