package com.example.electroduo;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "UserDatabase";
    public static final int DATABASE_VERSION = 10;
    // Tabla Usuarios
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_NOMBRE = "nombre";
    public static final String COLUMN_SINTOMAS = "sintomas";
    public static final String COLUMN_DOCTOR_ID = "doctor_id";
    public static final String COLUMN_MESSAGES = "messages";
    public static final String COLUMN_AGE = "age";
    public static final String COLUMN_PHONE_NUMBER = "phone_number";
    public static final String COLUMN_MEDICAL_RECORD_NUMBER = "medical_record_number";
    public static final String COLUMN_GENDER = "gender";
    public static final String COLUMN_HEIGHT = "height"; // Altura
    public static final String COLUMN_WEIGHT = "weight"; // Peso
    public static final String COLUMN_MEDICATIONS = "medications"; // Medicamentos
    public static final String COLUMN_DIAGNOSES = "diagnoses"; // Diagnósticos
    // SQL para crear la tabla de usuarios
    private static final String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
            COLUMN_ID + " TEXT PRIMARY KEY, " +
            COLUMN_PASSWORD + " TEXT, " +
            COLUMN_TYPE + " TEXT, " +
            COLUMN_NOMBRE + " TEXT, " +
            COLUMN_SINTOMAS + " TEXT, " +
            COLUMN_DOCTOR_ID + " TEXT, " +
            COLUMN_MESSAGES + " TEXT, " +
            COLUMN_AGE + " INTEGER, " +
            COLUMN_PHONE_NUMBER + " TEXT, " +
            COLUMN_MEDICAL_RECORD_NUMBER + " TEXT, " +
            COLUMN_GENDER + " TEXT, " +
            COLUMN_HEIGHT + " REAL, " + // Nueva columna para altura
            COLUMN_WEIGHT + " REAL, " + // Nueva columna para peso
            COLUMN_MEDICATIONS + " TEXT, " + // Nueva columna para medicamentos
            COLUMN_DIAGNOSES + " TEXT)"; // Nueva columna para diagnósticos
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        // Agregar usuarios de ejemplo
        addUser (db, "D01", "123", "DOCTOR", "José Luis Martínez", "Ninguno", "D01", "", 45, "1234567890", "MRN001", "Male", 1.75f, 70.0f, "Ninguno", "Ninguno"); // Mensajes vacíos
        addUser (db, "D02", "123", "DOCTOR", "Mia Johnson Pérez", "Ninguno", "D02", "", 50, "0987654321", "MRN002", "Female", 1.65f, 60.0f, "Ninguno", "Ninguno"); // Mensajes vacíos
        addUser (db, "D03", "123", "DOCTOR", "Yaguari López", "Ninguno", "D03", "", 60, "1122334455", "MRN003", "Male", 1.80f, 80.0f, "Ninguno", "Ninguno"); // Mensajes vacíos
        addUser (db, "P01", "123", "PACIENTE", "Pedro González", "", "D01", "", 30, "2233445566", "MRN004", "Male", 1.70f, 75.0f, "Paracetamol", "Ninguno"); // Mensajes vacíos
        addUser (db, "P02", "123", "PACIENTE", "Pablo Rodríguez", "", "D01", "", 28, "3344556677", "MRN005", "Male", 1.75f, 68.0f, "Ibuprofeno", "Ninguno"); // Mensajes vacíos
        addUser (db, "P03", "123", "PACIENTE", "Juan Pérez", "", "D02", "", 35, "4455667788", "MRN006", "Male", 1.80f, 85.0f, "Ninguno", "Hipertensión"); // Mensajes vacíos
        addUser (db, "P04", "123", "PACIENTE", "Ignacio Fernández", "", "D02", "", 40, "5566778899", "MRN007", "Male", 1.65f, 70.0f, "Ninguno", "Diabetes"); // Mensajes vacíos
        addUser (db, "P05", "123", "PACIENTE", "Ana María López", "", "D03", "", 25, "6677889900", "MRN008", "Female", 1.60f, 55.0f, "Ninguno", "Ninguno"); // Mensajes vacíos
        addUser (db, "P06", "123", "PACIENTE", "Laura Martínez", "", "D03", "", 32, "7788990011", "MRN009", "Female", 1.68f, 62.0f, "Ninguno", "Ninguno");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
// Método para añadir un nuevo usuario
private void addUser (SQLiteDatabase db, String id, String password, String type, String nombre, String sintomas, String doctorId, String messages, int age, String phoneNumber, String medicalRecordNumber, String gender, float height, float weight, String medications, String diagnoses) {
    ContentValues values = new ContentValues();
    values.put(COLUMN_ID, id);
    values.put(COLUMN_PASSWORD, password);
    values.put(COLUMN_TYPE, type);
    values.put(COLUMN_NOMBRE, nombre);
    values.put(COLUMN_SINTOMAS, sintomas);
    values.put(COLUMN_DOCTOR_ID, doctorId);
    values.put(COLUMN_MESSAGES, messages);
    values.put(COLUMN_AGE, age);
    values.put(COLUMN_PHONE_NUMBER, phoneNumber);
    values.put(COLUMN_MEDICAL_RECORD_NUMBER, medicalRecordNumber);
    values.put(COLUMN_GENDER, gender);
    values.put(COLUMN_HEIGHT, height); // Agregar altura
    values.put(COLUMN_WEIGHT, weight); // Agregar peso
    values.put(COLUMN_MEDICATIONS, medications); // Agregar medicamentos
    values.put(COLUMN_DIAGNOSES, diagnoses); // Agregar diagnósticos
    db.insert(TABLE_USERS, null, values);
}
    // Método para verificar las credenciales del usuario
    public Usuario checkUser (String id, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{
                            COLUMN_ID,
                            COLUMN_PASSWORD,
                            COLUMN_TYPE,
                            COLUMN_NOMBRE,
                            COLUMN_SINTOMAS,
                            COLUMN_DOCTOR_ID,
                            COLUMN_MESSAGES,
                            COLUMN_AGE,
                            COLUMN_PHONE_NUMBER,
                            COLUMN_MEDICAL_RECORD_NUMBER,
                            COLUMN_GENDER,
                            COLUMN_HEIGHT, // Nueva columna para altura
                            COLUMN_WEIGHT, // Nueva columna para peso
                            COLUMN_MEDICATIONS, // Nueva columna para medicamentos
                            COLUMN_DIAGNOSES // Nueva columna para diagnósticos
                    },
                    COLUMN_ID + "=? AND " + COLUMN_PASSWORD + "=?",
                    new String[]{id, password}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                Log.d("DatabaseCheck", "Usuario encontrado: " + cursor.getString(0));
                // Obtener los valores de sintomas y doctorId
                @SuppressLint("Range") String sintomas = cursor.getString(cursor.getColumnIndex(COLUMN_SINTOMAS));
                @SuppressLint("Range") String doctorId = cursor.getString(cursor.getColumnIndex(COLUMN_DOCTOR_ID));
                @SuppressLint("Range") String messages = cursor.getString(cursor.getColumnIndex(COLUMN_MESSAGES));
                @SuppressLint("Range") int age = cursor.getInt(cursor.getColumnIndex(COLUMN_AGE)); // Obtener edad
                @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex(COLUMN_PHONE_NUMBER)); // Obtener número de teléfono
                @SuppressLint("Range") String medicalRecordNumber = cursor.getString(cursor.getColumnIndex(COLUMN_MEDICAL_RECORD_NUMBER)); // Obtener número de historial médico
                @SuppressLint("Range") String gender = cursor.getString(cursor.getColumnIndex(COLUMN_GENDER)); // Obtener género
                @SuppressLint("Range") float height = cursor.getFloat(cursor.getColumnIndex(COLUMN_HEIGHT)); // Obtener altura
                @SuppressLint("Range") float weight = cursor.getFloat(cursor.getColumnIndex(COLUMN_WEIGHT)); // Obtener peso
                @SuppressLint("Range") String medications = cursor.getString(cursor.getColumnIndex(COLUMN_MEDICATIONS)); // Obtener medicamentos
                @SuppressLint("Range") String diagnoses = cursor.getString(cursor.getColumnIndex(COLUMN_DIAGNOSES)); // Obtener diagnósticos
                return new Usuario(cursor.getString(0), password, cursor.getString(2), cursor.getString(3), sintomas, doctorId, messages, age, phoneNumber, medicalRecordNumber, gender, height, weight, medications, diagnoses);
            } else {
                Log.d("DatabaseCheck", "Usuario no encontrado o credenciales incorrectas");
            }
        } catch (Exception e) {
            Log.e("DatabaseError", "Error al verificar el usuario", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return null;
    }

    public List<Usuario> getAllPatients(String doctorId) {
        List<Usuario> patientList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, "type=? AND doctor_id=?", new String[]{"PACIENTE", doctorId}, null, null, null); // Filtrar por tipo PACIENTE y doctor_id

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(COLUMN_ID));
                @SuppressLint("Range") String nombre = cursor.getString(cursor.getColumnIndex(COLUMN_NOMBRE));
                @SuppressLint("Range") String sintomas = cursor.getString(cursor.getColumnIndex(COLUMN_SINTOMAS)); // Obtener síntomas
                patientList.add(new Usuario(id, nombre, sintomas)); // Crear un nuevo objeto Usuario con síntomas
            }
            cursor.close();
        }
        return patientList;
    }
    @SuppressLint("Range")
    public String getSymptomsByPatientId(String patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        String sintomas = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_SINTOMAS},
                    COLUMN_ID + "=?", new String[]{patientId}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                sintomas = cursor.getString(cursor.getColumnIndex(COLUMN_SINTOMAS));
            }
        } catch (Exception e) {
            Log.e("DatabaseError", "Error al obtener síntomas", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return sintomas;
    }
    public void clearSymptomsByPatientId(String patientId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SINTOMAS, ""); // Establecer los síntomas a una cadena vacía
        // Actualizar los síntomas del paciente
        db.update(TABLE_USERS, values, COLUMN_ID + "=?", new String[]{patientId});

    }
    public void addMessage(String patientId, String message) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        // Obtener la fecha y hora actual
        String currentDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        // Concatenar la fecha y hora al mensaje
        String messageWithDate = currentDateTime + " - " + message;
        // Obtener el mensaje existente
        String existingMessages = getMessagesByPatientId(patientId);
        // Concatenar el nuevo mensaje
        if (existingMessages != null && !existingMessages.isEmpty()) {
            messageWithDate = existingMessages + "\n" + messageWithDate; // Añadir el nuevo mensaje
        }
        values.put(COLUMN_MESSAGES, messageWithDate);
        db.update(TABLE_USERS, values, COLUMN_ID + "=?", new String[]{patientId});
        db.close();
    }

    @SuppressLint("Range")
    public String getMessagesByPatientId(String patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        String messages = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_MESSAGES},
                    COLUMN_ID + "=?", new String[]{patientId}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                messages = cursor.getString(cursor.getColumnIndex(COLUMN_MESSAGES));
            }
        } catch (Exception e) {
            Log.e("DatabaseError", "Error al obtener mensajes", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return messages;
    }
    @SuppressLint("Range")
    public Usuario getPatientById(String patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Usuario paciente = null; // Inicializamos el objeto Usuario
        // Consulta para obtener el paciente por su ID
        Cursor cursor = db.query(TABLE_USERS, null, COLUMN_ID + "=?", new String[]{patientId}, null, null, null);
        // Verificamos si el cursor tiene resultados
        if (cursor != null && cursor.moveToFirst()) {
            String id = cursor.getString(cursor.getColumnIndex(COLUMN_ID));
            String password = cursor.getString(cursor.getColumnIndex(COLUMN_PASSWORD));
            String type = cursor.getString(cursor.getColumnIndex(COLUMN_TYPE));
            String nombre = cursor.getString(cursor.getColumnIndex(COLUMN_NOMBRE));
            String sintomas = cursor.getString(cursor.getColumnIndex(COLUMN_SINTOMAS));
            String doctorId = cursor.getString(cursor.getColumnIndex(COLUMN_DOCTOR_ID));
            String messages = cursor.getString(cursor.getColumnIndex(COLUMN_MESSAGES)); // Obtener mensajes
            // Nuevos campos que agregaste
            int age = cursor.getInt(cursor.getColumnIndex(COLUMN_AGE));
            String phoneNumber = cursor.getString(cursor.getColumnIndex(COLUMN_PHONE_NUMBER));
            String medicalRecordNumber = cursor.getString(cursor.getColumnIndex(COLUMN_MEDICAL_RECORD_NUMBER));
            String gender = cursor.getString(cursor.getColumnIndex(COLUMN_GENDER));
            float height = cursor.getFloat(cursor.getColumnIndex(COLUMN_HEIGHT)); // Obtener altura
            float weight = cursor.getFloat(cursor.getColumnIndex(COLUMN_WEIGHT)); // Obtener peso
            String medications = cursor.getString(cursor.getColumnIndex(COLUMN_MEDICATIONS)); // Obtener medicamentos
            String diagnoses = cursor.getString(cursor.getColumnIndex(COLUMN_DIAGNOSES)); // Obtener diagnósticos
            // Crear el objeto Usuario
            paciente = new Usuario(id, password, type, nombre, sintomas, doctorId, messages, age, phoneNumber, medicalRecordNumber, gender, height, weight, medications, diagnoses);
        }
        // Cerrar el cursor
        if (cursor != null) {
            cursor.close();
        }
        // Devolver el paciente encontrado o null si no se encontró
        return paciente;
    }
    public void updatePatient(String patientId, String nombre, int edad, String telefono, String numeroHistorial, String genero, float height, float weight, String medications, String diagnoses) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOMBRE, nombre);
        values.put(COLUMN_AGE, edad);
        values.put(COLUMN_PHONE_NUMBER, telefono);
        values.put(COLUMN_MEDICAL_RECORD_NUMBER, numeroHistorial);
        values.put(COLUMN_GENDER, genero);
        values.put(COLUMN_HEIGHT, height); // Nueva columna para altura
        values.put(COLUMN_WEIGHT, weight); // Nueva columna para peso
        values.put(COLUMN_MEDICATIONS, medications); // Nueva columna para medicamentos
        values.put(COLUMN_DIAGNOSES, diagnoses); // Nueva columna para diagnósticos
        // Actualizar la fila en la base de datos
        db.update(TABLE_USERS, values, COLUMN_ID + "=?", new String[]{patientId});
        db.close();
    }
}