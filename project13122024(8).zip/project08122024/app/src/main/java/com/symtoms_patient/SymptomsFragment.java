package com.symtoms_patient;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.electroduo.AgregarSintomasActivity;
import com.example.electroduo.DatabaseHelper;
import com.example.electroduo.MainActivity;
import com.example.electroduo.databinding.FragmentSymptomsBinding;

import java.util.ArrayList;
import java.util.List;

public class SymptomsFragment extends Fragment {
    private FragmentSymptomsBinding binding;
    private Button buttonOut, buttonAgregarSintomas;
    private ListView listViewSL;
    private SymptomsViewModel symptomsViewModel; // Usar ViewModel
    private ArrayAdapter<String> adapter;
    public View onCreateView(@NonNull LayoutInflater inflater,

                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSymptomsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        // Inicializar el DatabaseHelper y el ViewModel
        DatabaseHelper dbHelper = new DatabaseHelper(requireContext());
        symptomsViewModel = new ViewModelProvider(this).get(SymptomsViewModel.class);
        symptomsViewModel.initDatabaseHelper(requireContext());
        listViewSL = binding.listViewSL;
        buttonOut = binding.buttonOut;
        buttonAgregarSintomas = binding.buttonAgregarSintomas;
        adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, new ArrayList<>());
        listViewSL.setAdapter(adapter);
        String selectedPatientId = requireActivity().getIntent().getStringExtra("id");


        // Observar los síntomas desde el ViewModel

        symptomsViewModel.getSymptoms(selectedPatientId).observe(getViewLifecycleOwner(), symptomList -> {
            adapter.clear();
            adapter.addAll(symptomList);
            adapter.notifyDataSetChanged();
        });


        buttonAgregarSintomas.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), AgregarSintomasActivity.class);
            intent.putExtra("patient_id", selectedPatientId);
            startActivity(intent);
        });

        buttonOut.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), MainActivity.class);
            startActivity(intent);
            getActivity().finish();
        });
        return root;
    }
}