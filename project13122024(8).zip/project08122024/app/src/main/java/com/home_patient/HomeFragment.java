package com.home_patient;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.electroduo.AgregarSintomasActivity;
import com.example.electroduo.EditarInfoActivity;
import com.example.electroduo.GuidedStandingTestActivity;
import com.example.electroduo.MainActivity;
import com.example.electroduo.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private TextView textViewN, text5;
    private Button buttonOut,buttonLearnMore,buttonAgregarSintomas, buttonConductTest;
    private ImageButton buttonEditarInfo;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observe LiveData from ViewModel
        textViewN = binding.textViewN;
        textViewN.setText(requireActivity().getIntent().getStringExtra("nombre"));

        // Set up other buttons and actions
        //Register symptoms button
        buttonAgregarSintomas = binding.buttonAgregarSintomas;
        buttonAgregarSintomas.setOnClickListener(view -> {
            // Navigate to AgregarSintomasActivity
            Intent intent = new Intent(getActivity(), AgregarSintomasActivity.class);
            intent.putExtra("patient_id", getActivity().getIntent().getStringExtra("id"));
            startActivity(intent);
        });

        buttonOut = binding.buttonOut;
        buttonOut.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), MainActivity.class);
            startActivity(intent);
            getActivity().finish();
        });

        buttonEditarInfo = binding.Myinfo;
        buttonEditarInfo.setOnClickListener(view -> {
            // Navigate to EditarInfoActivity
            Intent intent = new Intent(getActivity(), EditarInfoActivity.class);
            intent.putExtra("id", getActivity().getIntent().getStringExtra("id"));
            startActivity(intent);
        });

        buttonLearnMore = binding.buttonLearnMore;
        text5 = binding.text5;
        buttonLearnMore.setOnClickListener(view -> {
            // Show information about POTStats and POTS
            text5.setVisibility(View.VISIBLE);
            buttonLearnMore.setVisibility(View.GONE);
        });

        buttonConductTest = binding.buttonConductTest;
        buttonConductTest.setOnClickListener(view -> {
            // Navigate to GuidedTest activity
            Intent intent = new Intent(getActivity(), GuidedStandingTestActivity.class);
            startActivity(intent);
            getActivity().finish();
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}